import json
import os
from datetime import datetime
from logger import logger

class DateTimeEncoder(json.JSONEncoder):
    """
    自定义JSON编码器，处理datetime类型
    """
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)

async def save_storage_data(page, state_file):
    """
    手动保存localStorage、IndexedDB和cookies数据到key-value store
    替代context.storage_state()
    """
    logger.info("手动保存localStorage、IndexedDB和cookies数据...")

    try:
        # 获取cookies
        cookies = await page.context.cookies()
        
        # 获取localStorage数据
        local_storage = await page.evaluate("""() => {
            const items = {};
            for (let i = 0; i < localStorage.length; i++) {
                const key = localStorage.key(i);
                items[key] = localStorage.getItem(key);
            }
            return items;
        }""")

        # 获取IndexedDB数据
        logger.info("开始获取IndexedDB数据...")
        indexed_db_data = await page.evaluate("""() => {
            const result = {};
            // 尝试获取所有IndexedDB数据库
            const databases = indexedDB.databases ? indexedDB.databases() : Promise.resolve([]);
            return databases.then(dbs => {
                const dbPromises = dbs.map(db => {
                    if (!db.name) return Promise.resolve(null);
                    return new Promise((resolve, reject) => {
                        const request = indexedDB.open(db.name, db.version);
                        request.onsuccess = (event) => {
                            const database = event.target.result;
                            const storeNames = database.objectStoreNames;
                            const stores = [];
                            
                            // 遍历所有存储对象
                            const storePromises = [];
                            for (let i = 0; i < storeNames.length; i++) {
                                const storeName = storeNames[i];
                                storePromises.push(new Promise((storeResolve) => {
                                    const transaction = database.transaction([storeName], 'readonly');
                                    const store = transaction.objectStore(storeName);
                                    const request = store.getAll();
                                    
                                    // 获取存储对象的信息（包括keyPath和索引）
                                    const storeInfo = {
                                        name: storeName,
                                        keyPath: store.keyPath,
                                        indexes: []
                                    };
                                    
                                    // 获取所有索引
                                    for (let j = 0; j < store.indexNames.length; j++) {
                                        const indexName = store.indexNames[j];
                                        const index = store.index(indexName);
                                        storeInfo.indexes.push({
                                            name: indexName,
                                            keyPath: index.keyPath,
                                            unique: index.unique
                                        });
                                    }
                                    
                                    request.onsuccess = (event) => {
                                        const items = event.target.result;
                                        // 处理ArrayBuffer类型
                                        const processedItems = items.map(item => {
                                            return JSON.parse(JSON.stringify(item, (key, value) => {
                                                if (value instanceof ArrayBuffer) {
                                                    // 将ArrayBuffer转换为Base64字符串
                                                    const uint8Array = new Uint8Array(value);
                                                    let binary = '';
                                                    for (let i = 0; i < uint8Array.byteLength; i++) {
                                                        binary += String.fromCharCode(uint8Array[i]);
                                                    }
                                                    return {
                                                        __type__: 'ArrayBuffer',
                                                        data: btoa(binary)
                                                    };
                                                }
                                                return value;
                                            }));
                                        });
                                        storeInfo.data = processedItems;
                                        stores.push(storeInfo);
                                        storeResolve();
                                    };
                                    
                                    request.onerror = (event) => {
                                        storeInfo.data = [];
                                        stores.push(storeInfo);
                                        storeResolve();
                                    };
                                }));
                            }
                            Promise.all(storePromises).then(() => {
                                database.close();
                                resolve({ name: db.name, version: db.version, stores });
                            });
                        };
                        request.onerror = (event) => {
                            resolve(null);
                        };
                    });
                });
                return Promise.all(dbPromises).then(results => {
                    return { databases: results.filter(Boolean) };
                });
            }).catch(() => ({ databases: [] }));
        }""")
        
        # 打印获取到的IndexedDB数据信息
        db_count = len(indexed_db_data.get('databases', []))
        logger.info(f"成功获取 {db_count} 个IndexedDB数据库")
        for db in indexed_db_data.get('databases', []):
            store_count = len(db.get('stores', []))
            total_data = sum(len(store.get('data', [])) for store in db.get('stores', []))
            logger.info(f"数据库: {db.get('name')}, 版本: {db.get('version')}, 存储对象: {store_count}, 数据总量: {total_data}")

        # 构建完整的状态数据
        state_data = {
            "cookies": cookies,
            "localStorage": local_storage,
            "indexedDB": indexed_db_data
        }

        # 推送到 KOFS store
        from apify import Actor
        state_file_store = await Actor.open_key_value_store(name='KOFS')
        await state_file_store.set_value('state.json', state_data, content_type='application/json')

        logger.info(f"状态数据已保存到 KOFS store: {len(cookies)}个cookies, {len(local_storage)}项localStorage数据, {db_count}个IndexedDB数据库")
        return True

    except Exception as e:
        logger.info(f"保存状态数据时发生异常: {e}")
        return False

def generate_restore_state_script(state_file):
    """
    生成用于在页面加载前恢复数据的初始化脚本
    """
    try:
        state_data = state_file
        if not state_data:
            logger.info("state.json为空，跳过生成恢复脚本")
            return None
        
        # 构建恢复脚本
        restore_state_script = """
        // 恢复localStorage数据
        const localStorageData = %s;
        for (const key in localStorageData) {
            if (localStorageData.hasOwnProperty(key)) {
                try {
                    localStorage.setItem(key, localStorageData[key]);
                } catch (e) {
                    console.error('设置localStorage失败:', key, e);
                }
            }
        }

        // 恢复IndexedDB数据
        const indexedDBData = %s;
        if (indexedDBData && indexedDBData.databases) {
            indexedDBData.databases.forEach(dbInfo => {
                if (dbInfo && dbInfo.name) {
                    // 首先删除已存在的数据库
                    const deleteReq = indexedDB.deleteDatabase(dbInfo.name);
                    deleteReq.onsuccess = () => {
                        // 删除成功后，创建新数据库
                        createDatabase(dbInfo);
                    };
                    deleteReq.onerror = () => {
                        // 删除失败也尝试创建
                        createDatabase(dbInfo);
                    };
                }
            });
        }

        function createDatabase(dbInfo) {
            // 创建或打开数据库
            const version = dbInfo.version || 1;
            const openReq = indexedDB.open(dbInfo.name, version);

            openReq.onupgradeneeded = (event) => {
                const database = event.target.result;
                // 创建存储对象，使用保存的keyPath
                if (dbInfo.stores) {
                    dbInfo.stores.forEach(storeInfo => {
                        if (!database.objectStoreNames.contains(storeInfo.name)) {
                            try {
                                // 使用保存的keyPath，默认为'id'
                                const keyPath = storeInfo.keyPath || 'id';
                                const objectStore = database.createObjectStore(storeInfo.name, { keyPath });
                                
                                // 创建保存的索引
                                if (storeInfo.indexes && storeInfo.indexes.length > 0) {
                                    storeInfo.indexes.forEach(indexInfo => {
                                        try {
                                            objectStore.createIndex(indexInfo.name, indexInfo.keyPath, {
                                                unique: indexInfo.unique || false
                                            });
                                        } catch (e) {
                                            console.error('创建索引失败:', indexInfo.name, e);
                                        }
                                    });
                                }
                            } catch (e) {
                                console.error('创建存储对象失败:', storeInfo.name, e);
                            }
                        }
                    });
                }
            };

            openReq.onsuccess = (event) => {
                const database = event.target.result;

                // 清空并恢复数据
                if (dbInfo.stores) {
                    dbInfo.stores.forEach(storeInfo => {
                        // 清空现有数据
                        const clearTransaction = database.transaction([storeInfo.name], 'readwrite');
                        const clearStore = clearTransaction.objectStore(storeInfo.name);
                        clearStore.clear();

                        // 恢复数据
                        if (storeInfo.data && storeInfo.data.length > 0) {
                            const addTransaction = database.transaction([storeInfo.name], 'readwrite');
                            const addStore = addTransaction.objectStore(storeInfo.name);

                            storeInfo.data.forEach((item) => {
                                // 处理ArrayBuffer数据
                                function processData(data) {
                                    if (Array.isArray(data)) {
                                        return data.map(processData);
                                    } else if (typeof data === 'object' && data !== null) {
                                        if (data.__type__ === 'ArrayBuffer') {
                                            // 将Base64转换为ArrayBuffer
                                            const binaryString = atob(data.data);
                                            const len = binaryString.length;
                                            const bytes = new Uint8Array(len);
                                            for (let i = 0; i < len; i++) {
                                                bytes[i] = binaryString.charCodeAt(i);
                                            }
                                            return bytes.buffer;
                                        }
                                        const result = {};
                                        for (const key in data) {
                                            if (data.hasOwnProperty(key)) {
                                                result[key] = processData(data[key]);
                                            }
                                        }
                                        return result;
                                    }
                                    return data;
                                }

                                const processedItem = processData(item);
                                addStore.add(processedItem);
                            });
                        }
                    });
                }

                database.close();
            };

            openReq.onerror = (event) => {
                console.error('打开数据库失败:', dbInfo.name, event.target.error);
            };
        }
        """ % (json.dumps(state_data.get('localStorage', {})), json.dumps(state_data.get('indexedDB', {})))
        
        return restore_state_script
        
    except Exception as e:
        logger.info(f"生成恢复脚本时发生异常: {e}")
        return None