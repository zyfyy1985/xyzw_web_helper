import os
import zipfile

def zip_directory(directory, zip_name, exclude_dirs):
    """将目录打包为zip文件，排除指定的目录"""
    # 获取zip文件名，用于排除
    zip_basename = os.path.basename(zip_name)
    
    with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # 遍历目录
        for root, dirs, files in os.walk(directory):
            # 排除指定的目录
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            # 添加文件到zip
            for file in files:
                # 排除zip文件本身
                if file == zip_basename:
                    continue
                
                file_path = os.path.join(root, file)
                # 计算相对路径，确保zip文件中的路径正确
                arcname = os.path.relpath(file_path, directory)
                zipf.write(file_path, arcname)

if __name__ == "__main__":
    # 项目根目录
    project_dir = os.path.dirname(os.path.abspath(__file__))
    # 输出zip文件名
    zip_name = os.path.join(project_dir, "KOFA.zip")
    # 要排除的目录
    exclude_dirs = ["logs", "storage", "__pycache__"]
    
    print(f"正在打包项目到 {zip_name}")
    print(f"排除的目录: {exclude_dirs}")
    
    zip_directory(project_dir, zip_name, exclude_dirs)
    
    print("打包完成！")
